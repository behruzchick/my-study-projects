<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="home.php" method='POST'>
        <label>Name</label>
        <input name='name' type="text"><br>
        <label>E-mail</label>
        <input name='email' type="text"><br>
        <label>Password</label>
        <input name='password' type="password"><br>
        <label>Confirm password</label>
        <input name='cpassword' type="password"><br>

        <button>Sumbit</button>
    </form>
</body>
</html>

<?php

?>