# Welcome to my Pokemon App!
demo : https://glistening-elf-3cd3e6.netlify.app
## Description
This project is a Pokemon app that allows users to research information about different Pokemon, view their stats, and virtually catch them. The goal of the project is to provide a fun and interactive experience for Pokemon fans.
## Usage

cd pokemon-app
Install Dependencies:
``````
npm install
Start the Application:

npm start
``````

## Instalation
Install Dependencies:
``````
cd pokemon-app

npm install
``````

## The core team 
This project maked solo.


