export const CREATE_FOLDER = 'CREATE_FOLDER';
export const ADD_FOLDERS = 'ADD_FOLDERS';
export const ADD_FILES = 'ADD_FILES';
export const SET_LOADING = 'SET_LOADING';
export const CHANGE_FOLDER = 'CHANGE_FOLDER';
export const CREATE_FILE = 'CREATE_FILE';
export const UPLOAD_FILE = 'UPLOAD_FILE';