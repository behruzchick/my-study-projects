import * as types from '../../Actions/AuthAction/AuthAction';
import { auth } from '../../../config/firebase';
// import fire from '../../config/firebase' 
import { getAuth, sendEmailVerification, updateCurrentUser, updateEmail, updateProfile } from 'firebase/auth';
import { createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword } from 'firebase/auth';

const loginUser = (user) => {
    return {
        type: types.SIGN_IN,
        payload: user,
    };
};

const logoutUser = (payload) => {
    return {
        type: types.SIGN_OUT,
        payload,
    };
};

const uptadeUser = (user) => {
    return {
        type: types.EDIT_USER,
        payload:user
    }
}

const setUser = (data) => ({
    type: types.SET_USER,
    payload: data,
});

export const signInUser = (email, password, setSuccess) => (dispatch) => {
    signInWithEmailAndPassword(auth, email, password)
        .then((user) => {
            dispatch(loginUser(user));
            console.log("Successfuly logined");
            setSuccess(true)
        })
        .catch((e) => {
            console.log("Invalid email or password!");
        });
};

export const signUpUser = (name, email, password, setSuccess) => (dispatch) => {
    console.log({name,email,password});
    createUserWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
            const user = userCredential.user;
            updateProfile(user, {
                displayName: name
            })
            .then(() => {
                console.log("Successfully registered!");
                dispatch(loginUser(user));
                setSuccess(true)
            })
            .catch((error) => {
                console.error("Error updating profile:", error);
            });
        })
        .catch((e) => {
            if (e.code === 'auth/email-already-in-use') {
                alert('Email already used!')
            }
            if (e.code === 'auth/invalid-email') {
                alert('Invalid email!')
            }
            if (e.code === 'auth/weak-password') {
                alert('Weak password!')
            }
        });
};


export const SignOut = (setSuccess) => (dispatch) => {
    auth.signOut().then(() => {
        dispatch(logoutUser())
        setSuccess(true)
    })
    dispatch(logoutUser());
};

export const checkIsLogged = (navigate) => (dispatch) => {
    onAuthStateChanged(auth, (user) => {
        if (user) {
            dispatch(dispatch(loginUser(user)))
            // navigate('/dashboard');
            console.log("logged true");
        } else {
            console.log("logged false");
            navigate('/login')
        }
    })
}


export const editUser = (name, photoUrl,navigate) => (dispatch) => {
    const user = auth.currentUser
    // const valEmail = email
    if (user) {
        const profileToUpdate = {};

        if (name) {
            profileToUpdate.displayName = photoUrl;
        }

        if (photoUrl) {
            profileToUpdate.photoUrl = name;

        }
        updateProfile(user, profileToUpdate)
        .then((res) => {
                dispatch(dispatch(uptadeUser(user)));
                console.log("Success", user);
                alert("Successfuly edited user!")
                navigate('/dashboard')
            })
            .catch((e) => {
                console.error("Error:", e);
            });
    } else {
        console.error("User not authenticated");
    }
};