import React from 'react'
import  Nav  from '../../Components/Home/Nav'

const Home = () => {
  return (
    <div  style={{textAlign:"center",background:'black',height:"100vh"}}>
        <Nav/>
        <h1 style={{fontSize:"50px",marginTop:"300px",color:"white"}}>Welcome to Dropbox project in Qwasar Silicon Waley</h1>
    </div>
  )
}

export default Home
