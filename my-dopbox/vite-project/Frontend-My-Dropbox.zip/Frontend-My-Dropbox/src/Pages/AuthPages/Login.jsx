import React from 'react'
import LoginForm from '../../Components/AuthComponents/LoginForm'
const Login = () => {
  return (
    <div className='login-page'>
        <LoginForm/>
    </div>
  )
}

export default Login