import React from 'react'
import RegisterForm from '../../Components/AuthComponents/RegisterForm'

const Register = () => {
  return (
    <div className='register-page'>
        <RegisterForm/>
    </div>
  )
}

export default Register