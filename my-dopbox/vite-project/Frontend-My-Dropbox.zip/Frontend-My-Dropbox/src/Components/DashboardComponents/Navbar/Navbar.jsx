import React, { useEffect } from 'react'
import './Navbar.css'
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import '../../Home/Nav.css'
import { useDispatch, useSelector } from 'react-redux'
import { SignOut } from '../../../redux/CreatorsAction/Auth/AuthActionCreator'
const Navbar = () => {

  const dispatch = useDispatch();
  const { isLogged, user } = useSelector((state) => state.auth || [])
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();

  console.log("userrrr", user);
  const handleLogout = (e) => {
    e.preventDefault();
    dispatch(SignOut(setSuccess));
  }

  useEffect(() => {

  },[user])

  return (
    <header className='h-navbar home-header'>
      <div className="nav-text-logo">
        <Link className='n text-logo h-logo' to={'/dashboard'} style={{ marginLeft: "20px" }}>Hello!    <b>{user === null ? "" : user.displayName}</b></Link>
      </div>
      <nav>
        <ul>
          {
            isLogged ? (
              <>
                <li>
                  <Link className="n nav-linkr l" onClick={handleLogout}>Logout</Link>
                  <Link className="n nav-link l" to={'/dashboard/edit/user'}>Edit profile</Link>
                </li>
              </>
            ) : (
              <>
                <li>
                  <Link className="n nav-link r" to={'/register'}>Register</Link>
                </li>
                <li>
                  <Link className="n nav-link l" to={'/login'}>Login</Link>
                </li>
              </>
            )
          }

        </ul>
      </nav>
    </header>
  )
}

export default Navbar