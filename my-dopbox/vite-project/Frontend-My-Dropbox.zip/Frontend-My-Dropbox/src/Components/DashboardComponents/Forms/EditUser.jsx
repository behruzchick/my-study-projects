import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import './CreateFolder.css'
import { editUser } from '../../../redux/CreatorsAction/Auth/AuthActionCreator';
import { useNavigate } from 'react-router-dom';
const EditUser = () => {
  const [name,setName] = useState("")
  const [photoUrl,setPhotoUrl] = useState("")
  const [oldEmail,setOldEmail] = useState("")
  const [password,setPassword] = useState("")
  // const { isLogged, isLoading, user } = useSelector((state) => ({
  //   isLogged: state.auth,
  //   isLoading: state.FileFoldersReducer?.isLoading || [],
  //   user: state.auth.user || []
  // })
  // );

  const navigate = useNavigate();
  const dispatch = useDispatch();

  // console.log("user", user);

  const handleSumbit = () => {
    try {
      if( name.length > 3 & photoUrl.length > 3 ){
        // const user = {
        //   name:name,
        //   email:email
        // }
        dispatch(editUser(photoUrl,name,navigate));
      }else{
        alert("Characters has been 3+")
      }
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <div style={{ display: "flex", alignItems: 'center', justifyContent: 'center', width: '100%', height: "100vh" }}>
      <div className="form">
        <h5 style={{color:"white",marginBottom:"15px",fontSize:"23px"}}>Edit profile</h5>
        {/* <label style={{color:"white"}} htmlFor="">Enter old  email and password</label> */}
        
        <form className='create-folder-form' style={{display:'flex',flexDirection:'column',gap:'10px'}}>
          {/* <input onChange={(e) => setOldEmail(e.target.value)} placeholder='Email' className='create-folder-input' />
          <input onChange={(e) => setPassword(e.target.value)} type='text' placeholder='Password' className='create-folder-input' /> */}
          {/* <label style={{color:"white"}} htmlFor=""></label> */}
          <input onChange={(e) => setName(e.target.value)} placeholder='Name' className='create-folder-input' />
          <input onChange={(e) => setPhotoUrl(e.target.value)} placeholder='Photo url' className='create-folder-input' />
        </form>
        <div className='btns_wrape'>
          <button onClick={handleSumbit} className='btn'  style={{ background: 'white', padding: "10px", border: "none", borderRadius: '10px', cursor: "pointer" ,marginTop:'15px'}}>Edit</button>
        </div>
      </div>

    </div>

  )
}

export default EditUser