import React, { useEffect } from 'react';
import { useGLTF, useAnimations } from '@react-three/drei';
import { MeshStandardMaterial } from 'three';

function Scene({ position, scale }) {
  const { scene, animations } = useGLTF('/scene.gltf');
  const { actions } = useAnimations(animations, scene);

  useEffect(() => {
    // scene.traverse((object) => {
    //   if (object.isMesh) {
    //     object.material = new MeshStandardMaterial({ color: '#D943B1' });
    //   }
    // });
    if (actions && actions[Object.keys(actions)[0]]) {
      actions[Object.keys(actions)[0]].play();
    }
  }, [scene, actions]);

  return <primitive object={scene}/>;
}

export default Scene;
