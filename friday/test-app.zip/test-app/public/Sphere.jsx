import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';

function Scene(props) {
  const { scene } = useGLTF('./voice.gltf');
  const ref = useRef();

  useFrame(() => {
    if (ref.current) {
      ref.current.rotation.y += 0.005;
      ref.current.rotation.x += 0.005;
      ref.current.rotation.z += 0.005;
    }
  });

  return <primitive object={scene} ref={ref} {...props} />;
}

export default Scene;