import React, { Suspense } from 'react'
import gif from '../../assets/gif.gif'
import './Main.css'
import Voice from '../../../public/Voice';
import { Canvas } from '@react-three/fiber';
import { Environment, OrbitControls } from '@react-three/drei';
import Scene from '../../../public/Sphere';
const Main = () => {
  return (
    <div className='main-wrappe'>
      <div className="cube-container">
        <div className="cube-animation">
          <Canvas
            camera={{ position: [0, 0, 7], fov: 30 }}
            style={{ width: '350px', height: '400px' }}
          >
            <ambientLight intensity={0.5} />
            <directionalLight intensity={1} position={[5, 5, 5]} />
            <pointLight intensity={0.5} position={[-5, -5, -5]} />
            <OrbitControls enableZoom={false} />
            <Suspense fallback={null}>
              <Environment preset="warehouse" />
              <Scene position={[0, 0, 0]} scale={[1, 1, 1]} />
            </Suspense>
          </Canvas>
        </div>
        <div className="friday-type">
          <b className='friday-answer text-answr' style={{ color: "#fff" }}>Hi, I am FRIDAY</b>
        </div>

      </div>
      <div className="user-voice-wawe">
        <b className='text-answr'>Stop, i don’t want to talk about it</b>
      </div>
    </div>
  )
}

export default Main













{/* <Canvas
          camera={{ position: [0, 0, 10], fov: 30 }}
          style={{ width: '1000px', height: '500px' }}
        >
          <ambientLight intensity={0.5} />
          <directionalLight intensity={1} position={[5, 5, 5]} />
          <pointLight intensity={0.5} position={[-5, -5, -5]} />
          <OrbitControls />
          <Suspense fallback={null}>
            <Environment preset="lobby" />
            <Scene position={[0, 0, 0]} scale={[1, 1, 1]} />
          </Suspense>
        </Canvas> */}