import React, { Suspense, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { Canvas } from '@react-three/fiber';
import { ContactShadows, Environment, OrbitControls, Stage } from '@react-three/drei'
import Scene from '../public/Scene';
import Header from './Components/Header/Header';
import Main from './Components/Main/Main';
function App() {
  const [open, setOpen] = useState(false);
  const [clicked,setClicked] = useState(false);


  const handleBoxCLick = () => {
    setClicked(false);
    setOpen(false)
  }
  return (
    <div className='main'>
      <Header clicked={clicked} setClicked={setClicked} open={open} setOpen={setOpen}/>
      <div onClick={handleBoxCLick} className="main-box">
        <Main/>
      </div>
    </div>
  )
}

export default App
